<?php
include ("config.php");
include ("lib_functions.php");
session_start(); //session start
header("Cache-Control: no-store, no-cache, must-revalidate");
if(isset($_SESSION['username']))
{
    $username     = $_SESSION['username'];
    $id_ejecutivo = $_SESSION['id_ejecutivo'];

    $qtyClientes   = getQtyClientesByEjecutivo($id_ejecutivo);
    $qtyClientesAct = getQtyClientesActivosByEjecutivo($id_ejecutivo);

    $qtyProspectos = getQtyProspectosByEjecutivo($id_ejecutivo);

    $ejecutivo = getEjecutivoByID($id_ejecutivo);

    $xmlSource = "http://indicadoresdeldia.cl/webservice/indicadores.xml";
    $xml       = simplexml_load_file($xmlSource);
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TMC Prospectos App</title>
    <link href='../resources/tmc.ico' rel='shortcut icon' type='image/x-icon'>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Sweet Alert Styles -->
    <link href="../css/sweetalert.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Prospectos App v<?= getAppVersion(); ?></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                        <li>
                            <a href="#">
                                <div>
                                    Nada que ver por aqui.
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>See All Alerts</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-alerts -->
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><i class="fa fa-terminal fa-fw"></i> <?= $username; ?></li>
                        <li class="divider"></li>
                        <li><a href="javascript:logout();"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <!-- /.navbar-top-links -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="side-user hidden-xs" align="center">
                            <br>       
                            <img class="img-circle" src="<?= getIMGByEjecutivo($id_ejecutivo); ?>" alt="">
                            <br><br>
                            <span class="pull-center text-muted small"><strong>Ejecutivo: </strong><?= $ejecutivo; ?></span>

                        </li>
                        <li selected>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <form id="loadMisClientes" method="post" action="loadMisClientes.php">
                                <input type='hidden' name='id_ejecutivo' value="<?= $id_ejecutivo; ?>"/>
                            </form>
                            <a href="javascript:loadMisClientes()"><i class="fa fa-group fa-fw"></i> Mis Clientes </a>
                        </li>                        
                        <li>
                            <form id="loadMisProspectos" method="post" action="loadMisProspectos.php">
                                <input type='hidden' name='id_ejecutivo' value="<?= $id_ejecutivo; ?>"/>
                            </form>
                            <a href="javascript:loadMisProspectos()"><i class="fa fa-tasks fa-fw"></i> Mis Prospectos</a>
                        </li>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><i class="fa fa-dashboard"></i> Dashboard </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                        <?= $qtyClientes; ?>
                                    </div>
                                    <div>Clientes</div>
                                </div>
                            </div>
                        </div>

                            <form id="loadMisClientes" method="post" action="loadMisClientes.php">
                                <input type='hidden' name='id_ejecutivo' value="<?= $id_ejecutivo; ?>"/>
                            </form>
                            <a href="javascript:loadMisClientes()">                    
                            <div class="panel-footer">
                                <span class="pull-left">Ver Detalles</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                        <?= $qtyProspectos; ?>
                                    </div>
                                    <div>Prospectos</div>
                                </div>
                            </div>
                        </div>
                        <form id="loadMisProspectos" method="post" action="loadMisProspectos.php">
                            <input type='hidden' name='id_ejecutivo' value="<?= $id_ejecutivo; ?>"/>
                        </form>
                        <a href="javascript:loadMisProspectos()"> 
                            <div class="panel-footer">
                                <span class="pull-left">Ver Detalles</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-trophy fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">20,3<i style="font-size:20px">%</i></div>
                                    <div>Metas Semanales</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Detalles</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">13</div>
                                    <div>Support Tickets!</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Estado Clientes
                        </div>
                        <div class="panel-body">
                            <div id="donut-clientes"></div>
                            <!-- <a href="#" class="btn btn-default btn-block">View Details</a> -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <div class="col-lg-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Estado Prospectos
                        </div>
                        <div class="panel-body">
                            <div id="donut-prospectos"></div>
                            <!-- <a href="#" class="btn btn-default btn-block">View Details</a> -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                 <div class="col-lg-2">

                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bell fa-fw"></i> Indicadores
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="list-group">
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-dollar fa-fw"></i> Dólar observado
                                    <span class="pull-right text-muted small"><em><?= $xml->moneda->dolar; ?></em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-euro fa-fw"></i> Euro
                                    <span class="pull-right text-muted small"><em><?= $xml->moneda->euro; ?></em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-money fa-fw"></i> Dólar interbancario
                                    <span class="pull-right text-muted small"><em><?= $xml->moneda->dolar_clp; ?></em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <span class="glyphicon glyphicon-usd" aria-hidden="true"></span>UF
                                    <span class="pull-right text-muted small"><em><?= $xml->indicador->uf; ?></em>
                                    </span>
                                </a>
                                <a href="#" class="list-group-item">
                                    <span class="glyphicon glyphicon-usd" aria-hidden="true"></span> UTM
                                    <span class="pull-right text-muted small"><em><?= $xml->indicador->utm; ?></em>
                                    </span>
                                </a>
                            </div>
                            <!-- /.list-group -->
                            <!-- <p class="help-block">Actualizado al: <?= $xml->author; ?>.</p> -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <!-- <script src="../data/morris-data.js"></script> -->

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <script src="../js/lib_ajax.js"></script>

    <!-- Sweet Alert Script -->
    <script src="../js/sweetalert.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
        // DONUT CHART CLIENTES
        Morris.Donut({
            element: 'donut-clientes',
            data: [
                {label: "Activos", value: <?= $qtyClientesAct; ?>},
                {label: "Inactivos", value: <?= $qtyClientes - $qtyClientesAct; ?>}
          ]
        });

        // DONUT CHART PROSPECTOS

        var colors_array= ["#5CB85C", "#8FB88F", "#A2BAA2"];
        Morris.Donut({
          element: 'donut-prospectos',
          resize: true,
          colors: colors_array,
          data: [
<?php
$sql = "SELECT t2.descripcion as descripcion, count(*) as count FROM dbcomercial.tbprospectos as t1, dbcomercial.tbestadoprospecto as t2
    WHERE t1.id_ejecutivo  = '$id_ejecutivo' AND t1.estado = t2.idtbestadoprospecto GROUP BY estado";
    $result = mysql_query($sql);
    $array_data = array();
    while($Reg = mysql_fetch_array($result))
    {
        echo '{label: "'.$Reg['descripcion'].'", value: '.$Reg['count'].'}, ';
    }
?>
          ]
        });
    });
    </script>

</body>
</html>
<?php
}else{
    header("location:login.html");
}
?>