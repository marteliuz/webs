<?php
include ("config.php");
include ("lib_functions.php");
$id_ejecutivo = $_POST['id_ejecutivo'];
$id_cliente = $_POST['id_cliente'];

$nombre_cliente = getNombreClienteById($id_cliente);

// echo "id_ejecutivo=".$id_ejecutivo."<br>";
// echo "id_cliente=".$id_cliente."<br>";
// echo "nombre_cliente=".$nombre_cliente."<br>";
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TMC Prospectos App</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Sweet Alert Styles -->
    <link href="../css/sweetalert.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

         <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                </button>
                <a class="navbar-brand" href="#">Prospectos App v<?php echo getAppVersion(); ?></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-comment fa-fw"></i> New Comment
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                    <span class="pull-right text-muted small">12 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-envelope fa-fw"></i> Message Sent
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-tasks fa-fw"></i> New Task
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>See All Alerts</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-alerts -->
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><i class="fa fa-terminal fa-fw"></i> <?php echo $_SESSION['username']; ?></li>
                        <li class="divider"></li>
                        <li><a href="javascript:logout();"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>

            <!-- /.navbar-top-links -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="side-user hidden-xs" align="center">
                            <br>       
                            <img class="img-circle" src="<?php echo getIMGByEjecutivo($id_ejecutivo); ?>" alt="">
                            <br><br>
                            <span class="pull-center text-muted small"><strong>Ejecutivo: </strong><?php echo getEjecutivoByID($id_ejecutivo); ?></span>

                        </li>
                        <!-- </li> -->
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li selected>
                            <form id="loadMisClientes" method="post" action="loadMisClientes.php">
                                <input type='hidden' name='id_ejecutivo' value="<?php echo $id_ejecutivo; ?>"/>
                            </form>
                            <a href="javascript:loadMisClientes()"><i class="fa fa-group fa-fw"></i> Mis Clientes </a>
                        </li>                        
                        <li>
                            <form id="loadMisProspectos" method="post" action="loadMisProspectos.php">
                                <input type='hidden' name='id_ejecutivo' value="<?php echo $id_ejecutivo; ?>"/>
                            </form>
                            <a href="javascript:loadMisProspectos()"><i class="fa fa-tasks fa-fw"></i> Mis Prospectos</a>
                        </li>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <br>
                    <!-- <h1 class='page-header'> <i class='fa fa-group fa-fw'></i> Mis Clientes</h1> -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class='panel panel-info'>
		                <div class='panel-heading'>
		                    <h3><i class='fa fa-group fa-fw'></i> Contactos de <?php echo $nombre_cliente; ?> </h3>
		                </div>
		                <!-- /.panel-heading -->
                        <div class="panel-body">
<?php
$qry      = "SELECT * FROM dbcomercial.tbcontactos WHERE id_ejecutivo = $id_ejecutivo AND id_cliente = $id_cliente AND activo = 1";
$result   = mysql_query($qry);
$num_rows = mysql_num_rows($result);
if($num_rows==0){
	echo "El cliente no tiene contactos creados.";
}else{
	echo "<table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                        <thead>
                            <tr>
                                <th><i class='fa fa-user fa-fw'></i> Nombre</th>
                                <th><i class='fa fa-briefcase fa-fw'></i> Cargo</th>
                                <th><i class='fa fa-envelope-o fa-fw'></i> Correo</th>
                                <th><i class='fa fa-phone fa-fw'></i> Telefono</th>
                            </tr>
                        </thead>
                        <tbody>";
    while($Reg = mysql_fetch_array($result))
	{
?>
		<tr>
			<td><?php echo $Reg['nombre_contacto']; ?></td>
			<td><?php echo $Reg['cargo_contacto']; ?></td>
			<td><?php echo "<a href='mailto:".$Reg['correo_contacto']."'>".$Reg['correo_contacto']."</a>"; ?></td>
			<td><?php echo $Reg['telefono_contacto']; ?></td>
		</tr>
<?php
	}
	echo "</tbody></table>";
}
?>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class='row'>
		        <div class='col-lg-12'>
		            <div class='panel panel-info'>
		                <div class='panel-heading'>
		                    Agregar Uno Nuevo.
		                </div>
		                <!-- /.panel-heading -->
		                <div class='panel-body'>
		                    <table width='80%' class='table table-striped table-bordered'>
		                        <thead>
		                            <tr>
		                                <th><i class='fa fa-user fa-fw'></i> <input type='text' class='form-control' id='input_nombre_contacto' placeholder='Nombre'> </th>
		                                <th><i class='fa fa-briefcase fa-fw'></i> <input type='text' class='form-control' id='input_cargo_contacto' placeholder='Cargo'> </th>
		                                <th><i class='fa fa-envelope-o fa-fw'></i> <input type='text' class='form-control' id='input_correo_contacto' placeholder='Correo'> </th>
		                                <th><i class='fa fa-phone fa-fw'></i> <input type='text' class='form-control' id='input_telefono_contacto' placeholder='Telefono'> </th>
		                            </tr>
		                        </thead>
		                        <tbody>
									<tr>
										<td colspan='4' align='right'> <button type='button' class='btn btn-success' onclick='javascript:agregaContacto(<?php echo $id_cliente; ?>, <?php echo $id_ejecutivo; ?>)'>Agregar</button></td>
									</tr>
								</tbody>
							</table>
						</div>
		            </div>
		        </div>
		    </div>
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <script src="../js/lib_ajax.js"></script>

        <!-- Sweet Alert Script -->
    <script src="../js/sweetalert.min.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        // $('#dataTables-example').DataTable({
        //     responsive: true
        // });
    });
    </script>

</body>
</html>