<?php
require("config/config.php");
if(!isset($_COOKIE['lg'])) {
    setcookie('lg', 'ro');
    $_COOKIE['lg'] = 'ro';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Encuesta</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />
	<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
	
	<script>
		$(document).ready(function(){
			$("#submit").click(function() {
				var id_cliente = document.getElementById("select-choice-1").selectedIndex;
				if(id_cliente!=0)
				{
				var value1 = $("#sliderQ1").val();
				var value2 = $("#sliderQ2").val();
				var value3 = $("#sliderQ3").val();
				var comments = $("#txtComments").val();
				
				ajax=objetoAjax();
				ajax.open("POST","procedures/qry_insert.php"+"?"+new Date().getTime(),true);
				ajax.onreadystatechange=function() {
					if (ajax.readyState==2){
						// alertify.log("Un momento... ");
					}
					if (ajax.readyState==4) {
						if(ajax.status==200){
							response = ajax.responseText;
							if(response=="OK"){
								alert("Muchas gracias por su tiempo.");
								location.reload();
							}
							if(response=="NO"){
								alert("D'Oh! algo sucediÛ :(")
							}
						}else if(ajax.status==404){
							alert("La direccion AJAX no existe");
						}else{
							alert("Error: ".ajax.status);
						}
					}
				
				}
				
				}else{
					alert("Recuerde seleccionar su empresa.");
				
				}
				ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				ajax.send("id_cliente="+id_cliente+"&question1="+value1+"&question2="+value2+"&question3="+value3+"&comments="+comments);
			 }
			 );
		 });
		
		function objetoAjax() {
			xmlhttp=false;
			this.AjaxFailedAlert = "Su navegador no soporta las funcionalidades de este sitio y podrÌa experimentarlo de forma diferente a la que fue pensada. Por favor habilite javascript en su navegador para verlo normalmente.\n";
			this.encodeURIString = true;
			this.execute = false;
			if (window.XMLHttpRequest) { 
				this.xmlhttp = new XMLHttpRequest();
				if (this.xmlhttp.overrideMimeType) {
					this.xmlhttp.overrideMimeType('text/xml');
				}
			} 
			else if (window.ActiveXObject) { // IE
				try {
					this.xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
				}catch (e) {
					try {
						this.xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {
						this.xmlhttp = null;
					}
				}
				if (!this.xmlhttp && typeof XMLHttpRequest!='undefined') {
					this.xmlhttp = new XMLHttpRequest();
					if (!this.xmlhttp){
						this.failed = true; 
					}
				} 
			}
			return this.xmlhttp ;
		}
	</script>
</head>
<body>

<div data-role="page" data-theme="a">
	<div data-role="header">
		<img id="logo" src="img/logo.png" style="width: 25%;">
		<h1>Satisfacci&oacute;n de clientes</h1>
	</div><!-- /header -->

	<div role="main" class="ui-content">
	<form>
		<table id="tbContent">
			<tbody>
				<tr>
					<td>Por favor responda las siguientes preguntas:<br></td>
				</tr>
				<tr>
					<td><div data-role="fieldcontain">
					<select name="select-choice-1" id="select-choice-1">
					<option value="0">> Seleccione su empresa <</option>
					<?php
					$qry = "SELECT * FROM tbclientes;";
					$result = mysql_query($qry);
					if (mysql_num_rows($result) > 0) {
					    // output data of each row
					    while($row = mysql_fetch_assoc($result)) {
					        echo "<option value='".$row['idtbclientes']."'>".$row['descripcion']."</option>";
					    }
					} else {
					    echo "<option value=''></option>";
					}
					?>
					</select>
					</div></td>
				</tr>
				<tr>
					<td><label>1.-&nbsp;<span style="font-size: 7pt;">&nbsp;</span>&iquest;Est&aacute; conforme con el tiempo de respuesta a su requerimiento?</label></td>
				</tr>
				<tr>
					<td><input type="range" name="sliderQ1" id="sliderQ1" min="1" max="7" value="1" data-popup-enabled="true"></td>
				</tr>
				<tr>
					<td>2.-&nbsp;&iquest;Est&aacute; conforme con la soluci&oacute;n entregada?</td>
				</tr>
				<tr>
					<td><input type="range" name="sliderQ2" id="sliderQ2" min="1" max="7" value="1" data-popup-enabled="true"></td>
				</tr>
				<tr>
					<td>3.-&nbsp;Una pregunta relacionada con la capacidad resolutiva del t&eacute;cnico.</td>
				</tr>
				<tr>
					<td><input type="range" name="sliderQ3" id="sliderQ3" min="1" max="7" value="1" data-popup-enabled="true"></td>
				</tr>
				<tr>
					<td>4.- Comentarios</td>
				</tr>
				<tr>
					<td><textarea name="txtComments" id="txtComments"  maxlength="100"></textarea></td>
				</tr>
				<tr>
					<td align="center"><input id="submit" type="button" value="Enviar" data-inline="true" data-icon="check" data-theme="b"/></td>
				</tr>
			</tbody>
		</table>
	</form>
	</div><!-- /content -->
	<div data-role="footer">
		<h4>by Marteliuz 2015</h4>
	</div><!-- /footer -->
</div><!-- /page -->
</body>
</html>
<?php	
}else{
	echo "Esta encuesta solo se puede responder una vez.";
}
?>