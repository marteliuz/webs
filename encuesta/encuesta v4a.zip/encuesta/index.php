<!DOCTYPE html>
<html lang="es"> 
<head> 
  <meta charset="utf-8" />
  <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>

	<script>
		$(document).ready(function(){
			var device = navigator.userAgent
			//alert(device);
			if (device.match(/Iphone/i)|| device.match(/Ipod/i)|| device.match(/Android/i)|| device.match(/J2ME/i)|| device.match(/BlackBerry/i)|| device.match(/iPhone|iPad|iPod/i)|| device.match(/Opera Mini/i)|| device.match(/IEMobile/i)|| device.match(/Mobile/i)|| device.match(/Windows Phone/i)|| device.match(/windows mobile/i)|| device.match(/windows ce/i)|| device.match(/webOS/i)|| device.match(/palm/i)|| device.match(/bada/i)|| device.match(/series60/i)|| device.match(/nokia/i)|| device.match(/symbian/i)|| device.match(/HTC/i))
			{ 
				window.location = "mobile.php";
			}else{
				window.location = "new.php";
			}
		});
  </script>
</head> 
<body> 
</body> 
</html>